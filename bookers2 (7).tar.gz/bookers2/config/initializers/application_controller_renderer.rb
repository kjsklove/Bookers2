# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ecd19f8cc3070f47484169ea9fe9b45e1bf955796effe8b33043ce57105dd9174e5808b4c349d72a39356aa6d732595433b2efae57ac370b345b9e8bed38dbc6'

